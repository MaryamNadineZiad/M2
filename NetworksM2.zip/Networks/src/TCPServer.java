import java.io.*;
import java.net.*;
import java.util.Scanner;

public class TCPServer {

	public static void main(String argv[]) throws Exception {
		String clientSentence;
		// String capitalizedSentence;

		ServerSocket welcomeSocket = new ServerSocket(6789);

		while (true) {

			Socket connectionSocket = welcomeSocket.accept();

			BufferedReader inFromClient = new BufferedReader(
					new InputStreamReader(connectionSocket.getInputStream()));

			while (true) {

				DataOutputStream outToClient = new DataOutputStream(
						connectionSocket.getOutputStream());
				if (inFromClient.ready()) {

					clientSentence = inFromClient.readLine();
					System.out.println("FROM CLIENT:"
							+ clientSentence.toUpperCase() + '\n');
				}
				BufferedReader sc = new BufferedReader(new InputStreamReader(
						System.in));
				if (sc.ready()) {
					String s = sc.readLine();
					String o = s + '\n';

					// capitalizedSentence = clientSentence.toUpperCase()
					// +s+'\n';

					try {

						outToClient.writeBytes(o);
						// outToClient.writeBytes(capitalizedSentence);

					} catch (Exception e) {
						System.out.println("Connection Failed");
						connectionSocket.close();
						break;
					}
				}
			}
			connectionSocket.close();
			break;
		}

	}
}
