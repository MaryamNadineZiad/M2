import java.io.*;
import java.net.*;

public class TCPClient {

	public static void main(String argv[]) throws Exception {
		String sentence;
		String modifiedSentence;

		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(
				System.in));

		Socket clientSocket = new Socket("192.168.43.111", 6789);

		DataOutputStream outToServer = new DataOutputStream(
				clientSocket.getOutputStream());
		BufferedReader inFromServer = new BufferedReader(new InputStreamReader(
				clientSocket.getInputStream()));

		while (true) {
			sentence = inFromUser.readLine();
			if (sentence.equals("connect")) {

				System.out.println("CONNECTION SUCESSS");
				while (true) {
					if (inFromUser.ready()) {
						sentence = inFromUser.readLine();
						outToServer.writeBytes(sentence + '\n');
					}
					if (inFromServer.ready()) {
						modifiedSentence = inFromServer.readLine();
						if (modifiedSentence.equals("OVER")) {
							System.out.println("connection terminated");
							clientSocket.close();
							break;
						}

						else {
							System.out.println("FROM SERVER: "
									+ modifiedSentence);
						}
					}
				}

			}

			else if (!(sentence.equals("CONNECT")))
				System.out.println("CANNOT CONNECT ");

		}
	}
}

